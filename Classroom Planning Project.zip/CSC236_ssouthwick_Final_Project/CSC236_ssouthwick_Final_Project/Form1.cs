﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace CSC236_ssouthwick_Final_Project
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            // Create a four second sleep timer for SplashScreen display time length.
            Thread thred = new Thread(new ThreadStart(SplashStart));
            thred.Start();
            Thread.Sleep(4000);         //// 4000 = 4 seconds.
            InitializeComponent();
            thred.Abort();
        }
        // Open SplashScreen form.
        public void SplashStart()
        {
            Application.Run(new SplashScreen());
        }
        // Exit application execution.
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // Open ViewClassroom modal form.
        private void buttonViewClassroom_Click(object sender, EventArgs e)
        {
            ViewClassroom myViewClassroom = new ViewClassroom(); myViewClassroom.ShowDialog();

        }
        // Open AddClassroom modal form.
        private void buttonAddClassroom_Click(object sender, EventArgs e)
        {
            AddClassroom myAddClassroom = new AddClassroom(); myAddClassroom.ShowDialog();
        }
    }
}
