﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC236_ssouthwick_Final_Project
//
//  Sheryl Southwick
//           Classroom Proposal
//                  Final Project   
{
    public partial class SplashScreen : Form
    {
        public SplashScreen()
        {
            InitializeComponent();
        }
        // Set a SplashScreen timer.
        private void timer1_Tick(object sender, EventArgs e)
        {
            // Increment progress bar to 100, then stop timer.
            progressBar1.Increment(1);
            if (progressBar1.Value == 100)
                timer1.Stop();
        }
    }
}
