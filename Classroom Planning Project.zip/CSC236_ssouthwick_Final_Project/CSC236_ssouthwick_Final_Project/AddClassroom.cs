﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CSC236_ssouthwick_Final_Project
//
//  Sheryl Southwick
//           Classroom Proposal
//                  Final Project
{
    public partial class AddClassroom : Form
    {
        // Create empty strings for building, desk, chair, computer, instructor station, all_info.
        string[] building = {"", "", "" }; string[] desk = { "", "", "" }; string[] chair = { "", "", "" };
        string[] cpu = { "", "", "" }; string[] inst = { "", "" }; string[] all_info = new string[14];

        // Create myClass, myDesk, myChair, myCPU, myInst, theDesk, theChair, theCPU, theInst objects.
        Classroom1 myClass = new Classroom1();
        Furnishings myDesk = new Furnishings(); Desk theDesk = new Desk();
        Furnishings myChair = new Furnishings(); Chair theChair = new Chair();
        Furnishings myCPU = new Furnishings(); CPU theCPU = new CPU();
        Furnishings myInst = new Furnishings(); InstStn theInst = new InstStn();

        public AddClassroom()
        {
            InitializeComponent();
        }
        // Show new groupbox buttons, or close form and return to Main Menu. 
        private void buttonExit_Click(object sender, EventArgs e)
        {
            // If InfoWillBeLost() returns true, show groupbox containing information lost
            // message and button options stay on page or leave page.
            if (InfoWillBeLost())
            {
                groupBox1.Visible = true;
            }
            // Or, InfoWillBeLost() returns false, close form and return to Main Menu.
            else
            {
                this.Close();
            }
        }
        ///////////////////////////////////////////////////////////////////// 
        //The code below demonstrates •	Creating custom methods.           // 
        ///////////////////////////////////////////////////////////////////// 

        // Check all text entries to see if any data has been entered, and return boolean true for yes 
        // or false for no.
        private bool InfoWillBeLost()
        {
            myClass.Name = textBoxRoomName.Text; // Get Name from textbox.
            myClass.Location = textBoxBuildingLocation.Text; // Get Location from textbox.

            // If class_info - name, location, room number, or prices, or qty are not empty strings, data_lost is true.
            // Return boolean data_lost.
            bool class_info = (myClass.Name != "") || (myClass.Location != "") || (textBoxRoomNumber.Text != "");
            bool prices = (myDesk.Price > 0 || myChair.Price > 0 || myCPU.Price > 0 || myInst.Price > 0);
            bool qty = (myDesk.Qty > 0 || myChair.Qty > 0 || myCPU.Qty > 0);
            bool data_lost = (class_info || prices || qty);
            return data_lost;
        }
        // Execute ClearInfo() method to clear all textboxes.
        private void buttonClear_Click(object sender, EventArgs e)
        {
            ClearInfo();
        }
        // Execute ValidateAndSaveInfo() method to validate and save data.
        private void buttonSave_Click(object sender, EventArgs e)
        {
            ValidateAndSaveInfo();
        }
        // Execute ValidateAndSaveInfo() method to validate and save data, 
        // then ClearInfo() method to clear all textboxes.
        private void buttonAddRoom_Click(object sender, EventArgs e)
        {
            bool valid = InfoIsValid();
            if (valid == true)
            {
                SaveInfoToFile();
                ClearInfo();
            }
        }
        // Execute InfoIsValid() method to validate info, and SaveInfoToFile to save, if valid.
        private void ValidateAndSaveInfo()
        {
            bool valid = InfoIsValid();
            if (valid == true)
            {
                SaveInfoToFile();
            }
        }
        private bool InfoIsValid()
        {
            ///////////////////////////////////////////////////////////////////// 
            //The code below demonstrates •	Declaring variables and constants .// 
            ///////////////////////////////////////////////////////////////////// 

            // Assign variable room_number to zero. Assign class name and location from textboxes, 
            // and boolean values to not empty strings and to room_number between 0 and 10000.
            myClass.Name = textBoxRoomName.Text; int room_number = 0;
            myClass.Location = textBoxBuildingLocation.Text;
            bool roomname = (myClass.Name != ""); bool loc = (myClass.Location != "");
            bool class_number = ((int.TryParse(textBoxRoomNumber.Text, out room_number))&& 
                room_number > 0 && room_number < 10000);

            // Assign boolean prices and quantities from class values, 
            // and boolean valid from room name and location and number and prices and quantities.
            bool prices = (myDesk.Price > 0 && myChair.Price > 0 && myCPU.Price > 0 && myInst.Price > 0);
            bool qty = (myDesk.Qty > 0 && myChair.Qty > 0 && myCPU.Qty > 0);
            bool valid = (roomname && loc && class_number && prices && qty);

            ///////////////////////////////////////////////////////////////////// 
            //The code below demonstrates if statements.                       // 
            ///////////////////////////////////////////////////////////////////// 

            // If one of the variables return false, show corresponding message, only one message at a time.
            if (roomname==false)
            {
                MessageBox.Show("Ener Valid Room Name");
            }
            else if (loc == false)
            {
                MessageBox.Show("Ener Valid Location.");
            }
            else if (class_number == false)
            {
                MessageBox.Show("Enter Classroom number between 0001 and 9999.");
            }
            else if (prices == false)
            {
                MessageBox.Show("Please select desk and chair and computer and instructor station.");
            }
            else if (qty == false)
            {
                MessageBox.Show("Please select desk and chair and computer quantity.");
            }
            // Or, if all true, create a building array containing name, location, and room number.
            else
            {
                building[0] = myClass.Name; building[1] = myClass.Location;
                myClass.RoomNumber = int.Parse(textBoxRoomNumber.Text);
                building[2] = myClass.RoomNumber.ToString();

            }
            // Return true or false for valid.
            return valid;
        }

        // Save all data to "Classroom Data.txt" file.
        private void SaveInfoToFile()
        {
            ///////////////////////////////////////////////////////////////////// 
            //The code below demonstrates •	Using and array or list.           // 
            ///////////////////////////////////////////////////////////////////// 

            // Add all data to all_info array, set count to zero.
            string[]all_info= {building[0], building[1], building[2], desk[0], desk[1], desk[2],
                chair[0], chair[1], chair[2], cpu[0],  cpu[1], cpu[2], inst[0],
                inst[1]};
            int count = 0;

            ///////////////////////////////////////////////////////////////////// 
            //The code below demonstrates writing and reading data from a file.// 
            ///////////////////////////////////////////////////////////////////// 

            // Declare a StreamWriter Variable. Assign a file and get a StreamWriter object.
            StreamWriter outputFile = File.AppendText("Classroom Data.txt");

            ///////////////////////////////////////////////////////////////////// 
            //The code below demonstrates using a loop.                        // 
            ///////////////////////////////////////////////////////////////////// 
            while (count < 14)
            {
                // Write reportline to file. 
                outputFile.WriteLine(all_info[count]); 
                count++;
            }
            // Close the file.
            outputFile.Close();

            // Display message that info is saved.
            MessageBox.Show("Classroom Saved.");
        }
        // Clear all textboxes and values.
        private void ClearInfo()
        {
            textBoxRoomName.Text = "";
            textBoxBuildingLocation.Text = "";
            textBoxRoomNumber.Text = "";
            textBoxDesk.Text = ""; myDesk.Price = 0;
            textBoxChair.Text = ""; myChair.Price = 0;
            textBoxCPU.Text = ""; myCPU.Price = 0;
            textBoxInst.Text = ""; myInst.Price = 0;
            bxQtyDesk.Text = "0"; myDesk.Qty = 0;
            bxQtyChair.Text = "0"; myChair.Qty = 0;
            bxQtyCPU.Text = "0"; myCPU.Qty = 0;
            lblSubCost.Text = "0"; 
            labelTotal.Text = "0";
        }
        // Assign desk price and style each time a listbox item is selected.
        private void listBoxDesk_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Show selected item in text box.
            textBoxDesk.Text = listBoxDesk.SelectedItem.ToString();

            // Get item's selected index.
            int item = listBoxDesk.SelectedIndex;

            // Assign style and price to class method returns, according to selected index.
            myDesk.Style = theDesk.DeskStyle(item);
            myDesk.Price = theDesk.DeskPrice(item);

            // Fill array with style and price values.
            desk[0] = myDesk.Style.ToString();
            desk[1] = myDesk.Price.ToString();

            // Execute FillTotals method to calculate and display all values.
            FillTotals();
        }
        // Assign chair price and style each time a listbox item is selected.
        private void listBoxChair_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Show selected item in text box.
            textBoxChair.Text = listBoxChair.SelectedItem.ToString();

            // Get item's selected index.
            int item = listBoxChair.SelectedIndex;

            // Assign style and price to class method returns, according to selected index.
            myChair.Style = theChair.ChairStyle(item);
            myChair.Price = theChair.ChairPrice(item);

            // Fill array with style and price values.
            chair[0] = myChair.Style.ToString();
            chair[1] = myChair.Price.ToString();

            // Execute FillTotals method to calculate and display all values.
            FillTotals();

        }
        // Assign computer price and style each time a listbox item is selected.
        private void listBoxCPU_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Show selected item in text box.
            textBoxCPU.Text = listBoxCPU.SelectedItem.ToString();

            // Get item's selected index.
            int item = listBoxCPU.SelectedIndex;

            // Assign style and price to class method returns, according to selected index.
            myCPU.Style = theCPU.CPUStyle(item);
            myCPU.Price = theCPU.CPUPrice(item);

            // Fill array with style and price values.
            cpu[0] = myCPU.Style.ToString();
            cpu[1] = myCPU.Price.ToString();

            // Execute FillTotals method to calculate and display all values.
            FillTotals();
        }
        // Assign instructor station price and style each time a listbox item is selected.
        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Show selected item in text box.
            textBoxInst.Text = listBoxInst.SelectedItem.ToString();

            // Get item's selected index.
            int item = listBoxInst.SelectedIndex;

            // Assign style and price to class method returns, according to selected index.
            myInst.Style = theInst.InstStnStyle(item);
            myInst.Price = theInst.InstStnPrice(item);

            // Fill array with style and price values.
            inst[0] = myInst.Style.ToString();
            inst[1] = myInst.Price.ToString();

            // Execute FillTotals method to calculate and display all values.
            FillTotals();

        }
        // Validate and assign desk quantity each time a listbox item is selected.
        private void bxQtyDesk_TextChanged(object sender, EventArgs e)
        {
            // Create integer variable.
            int desk_quantity;

            ///////////////////////////////////////////////////////////////////// 
            //The code below demonstrates exception handling.                  // 
            ///////////////////////////////////////////////////////////////////// 

            // Execute if quantity is an integer.
            if (int.TryParse(bxQtyDesk.Text, out desk_quantity))
            {
                // Quantity must be less than 100.
                if (desk_quantity < 100)
                {
                    // Quantity must be greater than 0. Assign class quantity and add
                    // value to array.
                    if (desk_quantity >= 0)
                    {
                        myDesk.Qty = desk_quantity;
                        desk[2] = myDesk.Qty.ToString();
                        FillTotals();
                    }
                    else
                    {
                        // Show message if quantity is not between 0 and 100, and set value to zero.
                        MessageBox.Show("Invalid amount.");
                        desk_quantity = 0;
                    }
                }
                else
                {
                    // Show message if quantity is not between 0 and 100, and set value to zero.
                    MessageBox.Show("Too many.");
                    desk_quantity = 0;
                }
            }
            // Execute if quantity is not an integer.
            else
            {
                // Show message if quantity is not an empty string.
                if (bxQtyDesk.Text != "")
                {
                    MessageBox.Show("Invalid Quantity.");
                    desk_quantity = 0;
                }
            }
        }
        // Validate and assign chair quantity each time a listbox item is selected.
        private void bxQtyChair_TextChanged(object sender, EventArgs e)
        {
            // Create integer variable.
            int chair_quantity;

            // Execute if quantity is an integer.
            if (int.TryParse(bxQtyChair.Text, out chair_quantity))
            {
                // Quantity must be less than 100.
                if (chair_quantity < 100)
                {
                    // Quantity must be greater than 0. Assign class quantity and add
                    // value to array.
                    if (chair_quantity >= 0)
                    {
                        myChair.Qty = chair_quantity;
                        chair[2] = myChair.Qty.ToString();
                        FillTotals();
                    }
                    else
                    {
                        // Show message if quantity is not between 0 and 100, and set value to zero.
                        MessageBox.Show("Invalid amount.");
                        chair_quantity = 0;
                    }
                }
                else
                {
                    // Show message if quantity is not between 0 and 100, and set value to zero.
                    MessageBox.Show("Too many.");
                    bxQtyChair.Text = "";
                }
            }
            // Execute if quantity is not an integer.
            else
            {
                // Show message if quantity is not an empty string.
                if (bxQtyChair.Text != "")
                {
                    MessageBox.Show("Invalid Quantity.");
                    bxQtyChair.Text = "";
                }
            }
        }
        // Validate and assign computer quantity each time a listbox item is selected.
        private void bxQtyCPU_TextChanged(object sender, EventArgs e)
        {
            // Create integer variable.
            int cpu_quantity;

            // Execute if quantity is an integer.
            if (int.TryParse(bxQtyCPU.Text, out cpu_quantity))
            {
                // Quantity must be less than 100.
                if (cpu_quantity < 100)
                {
                    // Quantity must be greater than 0. Assign class quantity and add
                    // value to array.
                    if (cpu_quantity >= 0)
                    {
                        myCPU.Qty = cpu_quantity;
                        cpu[2] = myCPU.Qty.ToString();
                        FillTotals();
                    }
                    else
                    {
                        // Show message if quantity is not between 0 and 100, and set value to zero.
                        MessageBox.Show("Invalid amount.");
                        cpu_quantity = 0;
                    }
                }
                else
                {
                    // Show message if quantity is not between 0 and 100, and set value to zero.
                    MessageBox.Show("Too many.");
                    bxQtyCPU.Text = "";
                }
            }
            // Execute if quantity is not an integer.
            else
            {
                // Show message if quantity is not an empty string.
                if (bxQtyCPU.Text != "")
                {
                    MessageBox.Show("Invalid Quantity.");
                    bxQtyCPU.Text = "";
                }
            }
        }
        // Calculate all subtotals and total, and display in corresponding textboxes.
        private void FillTotals()
        {
            lblSubtDesk.Text = (myDesk.Qty * myDesk.Price).ToString("n");
            lblSubtChair.Text = (myChair.Qty * myChair.Price).ToString("n");
            lblSubtCPU.Text = (myCPU.Qty * myCPU.Price).ToString("n");
            decimal sub_cost = (myDesk.Qty * myDesk.Price) + (myChair.Qty * myChair.Price) +
                 (myCPU.Qty * myCPU.Price);
            lblSubCost.Text = sub_cost.ToString("n");
            labelTotal.Text = (sub_cost + myInst.Price).ToString("n");
        }
        // Hide groupbox1 and stay on AddClassroom page.
        private void buttonStay_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
        }

        // Close form and return to main menu.
        private void buttonLeave_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
