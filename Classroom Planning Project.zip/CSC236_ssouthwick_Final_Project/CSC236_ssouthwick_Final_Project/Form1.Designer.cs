﻿namespace CSC236_ssouthwick_Final_Project
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.buttonViewClassroom = new System.Windows.Forms.Button();
            this.buttonAddClassroom = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonViewClassroom
            // 
            this.buttonViewClassroom.BackColor = System.Drawing.Color.SteelBlue;
            this.buttonViewClassroom.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonViewClassroom.Location = new System.Drawing.Point(642, 154);
            this.buttonViewClassroom.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.buttonViewClassroom.Name = "buttonViewClassroom";
            this.buttonViewClassroom.Size = new System.Drawing.Size(178, 50);
            this.buttonViewClassroom.TabIndex = 4;
            this.buttonViewClassroom.Text = "View Classroom";
            this.buttonViewClassroom.UseVisualStyleBackColor = false;
            this.buttonViewClassroom.Click += new System.EventHandler(this.buttonViewClassroom_Click);
            // 
            // buttonAddClassroom
            // 
            this.buttonAddClassroom.BackColor = System.Drawing.Color.SteelBlue;
            this.buttonAddClassroom.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonAddClassroom.Location = new System.Drawing.Point(642, 232);
            this.buttonAddClassroom.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.buttonAddClassroom.Name = "buttonAddClassroom";
            this.buttonAddClassroom.Size = new System.Drawing.Size(178, 50);
            this.buttonAddClassroom.TabIndex = 5;
            this.buttonAddClassroom.Text = "Add Classroom";
            this.buttonAddClassroom.UseVisualStyleBackColor = false;
            this.buttonAddClassroom.Click += new System.EventHandler(this.buttonAddClassroom_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.SteelBlue;
            this.buttonExit.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonExit.Location = new System.Drawing.Point(695, 520);
            this.buttonExit.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(125, 47);
            this.buttonExit.TabIndex = 6;
            this.buttonExit.Text = "EXIT";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label1.Location = new System.Drawing.Point(399, 46);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(442, 69);
            this.label1.TabIndex = 7;
            this.label1.Text = "Community College of Aurora Proposed Classroom Planning";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label2.Location = new System.Drawing.Point(29, 584);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 19);
            this.label2.TabIndex = 8;
            this.label2.Text = "by Sheryl Southwick";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(32, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(171, 66);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(879, 588);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonAddClassroom);
            this.Controls.Add(this.buttonViewClassroom);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "MainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Menu";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonViewClassroom;
        private System.Windows.Forms.Button buttonAddClassroom;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

