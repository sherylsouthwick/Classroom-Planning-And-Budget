﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CSC236_ssouthwick_Final_Project
//
//  Sheryl Southwick
//           Classroom Proposal
//                  Final Project   
{
    public partial class ViewClassroom : Form
    {
        // Create Class, Desk, Chair, Computer, and Instructor Station objects.
        Classroom1 myClass = new Classroom1();
        Furnishings myDesk = new Furnishings(); Desk theDesk = new Desk();
        Furnishings myChair = new Furnishings(); Chair theChair = new Chair();
        Furnishings myCPU = new Furnishings(); CPU theCPU = new CPU();
        Furnishings myInst = new Furnishings(); InstStn theInst = new InstStn();

        public ViewClassroom()
        {
            InitializeComponent();
        }
        // Method to get saved classroom information from file "Classroom Data.txt" and return as array.
        private string[] GetClassroomInfo()
        {
            // Create string array holding 500 items, set file_line_count counter to zero.
            string[] get_class_info = new string[500]; int file_line_count = 0;

            // Declare a StreamReader Variable.
            StreamReader inputFile;

            // Open file and get StreamReader object.
            inputFile = File.OpenText("Classroom Data.txt");


            // Loop to read file contents.
            while (!inputFile.EndOfStream)
            {
                //  Get line of data and assign thisline value to line.
                string thisline = inputFile.ReadLine();

                // Assign thisline string to array item that is equal to file_line_count.
                get_class_info[file_line_count] = thisline; file_line_count++;
            }

            // Close the file.
            inputFile.Close();

            // Assign a new string class_info, whose length equals file_line_count, set item_number counter to zero.
            string[] class_info = new string[file_line_count]; int item_number = 0;

            // Loop from item_number (zero) to file_line_count(get_class_info array item length).
            while (item_number < file_line_count)
            {
                // Assign each respective class_info string value to equal get_class_info string value.
                class_info[item_number] = get_class_info[item_number]; item_number++;
            }
            // return array class_info, which is a copy of the "Classroom Data.txt" file information.
            return class_info;
        }
        // Method to display all data in class_info array in labels
        private string[] DisplayClassroomInfo()
        {
            // Assign page and item values and get class_info array.
            int page = int.Parse(lblPage.Text); // Starts at one and changes according to previous or next button press.
            int item = (page-1) * 14; // Starts at zero, increments by 14 (for 14 data items per classroom) 0,14,28,42...

            // Assign class_info the returned array from GetClassroomInfo() method to get "Classroom Data.txt" file data.
            string[] class_info = GetClassroomInfo();

            // Assign array text value to corresponding labels via Classroom1 class.                     *********************
            myClass.Name = class_info[item + 0]; // Room name, item 0 of each saved classroom. 
            labelRoomName.Text = myClass.Name;
            myClass.Location = class_info[item + 1]; // Building Location, item 1 of each saved classroom.
            labelBuildingLocation.Text = myClass.Location;
            myClass.RoomNumber = int.Parse(class_info[item + 2]); // Room Number, item 2 of each saved classroom.
            labelRoomNumber.Text = myClass.RoomNumber.ToString();

            // Assign array text value to corresponding labels via inherited Furnishings class.             **********************
            myDesk.Style = class_info[item + 3]; // Desk Type, item 3 of each saved classroom.
            labelDeskType.Text = myDesk.Style;
            myDesk.Price = decimal.Parse(class_info[item + 4]); // Desk Price, item 4 of each saved classroom.
            labelDeskPrice.Text = myDesk.Price.ToString("n"); 
            myDesk.Qty = int.Parse(class_info[item + 5]); // Desk Quantity, item 5 of each saved classroom.
            labelQtyDesk.Text = myDesk.Qty.ToString(); 
            myChair.Style = class_info[item + 6]; // Chair Type, item 6 of each saved classroom.
            labelChairType.Text = myChair.Style; 
            myChair.Price = decimal.Parse(class_info[item + 7]); // Chair Price, item 7 of each saved classroom.
            labelChairPrice.Text = myChair.Price.ToString("n"); 
            myChair.Qty = int.Parse(class_info[item + 8]); // Chair Quantity, item 8 of each saved classroom.
            labelQtyChair.Text = myChair.Qty.ToString(); 
            myCPU.Style = class_info[item + 9]; // Computer Type, item 9 of each saved classroom.
            labelCPUType.Text = myCPU.Style; 
            myCPU.Price = decimal.Parse(class_info[item + 10]); // Computer Price, item 10 of each saved classroom.
            labelCpuPrice.Text = myCPU.Price.ToString("n"); 
            myCPU.Qty = int.Parse(class_info[item + 11]); // Computer Quantity, item 11 of each saved classroom.
            labelQtyCpu.Text = myCPU.Qty.ToString(); 
            myInst.Style = class_info[item + 12]; // Instructor Station Type, item 12 of each saved classroom.
            label1InstType.Text = myInst.Style; 
            myInst.Price = decimal.Parse(class_info[item + 13]); // Instructor Station Price, item 13 of each saved classroom.
            labelInstStnPrice.Text = myInst.Price.ToString("n"); 

            // Assign calculated values for desk, chair, and computer subtotals equal to price times quantity.
            decimal sub_desk = (decimal.Parse(labelDeskPrice.Text)) * (int.Parse(labelQtyDesk.Text));
            decimal sub_chair = (decimal.Parse(labelChairPrice.Text)) * (int.Parse(labelQtyChair.Text));
            decimal sub_cpu = (decimal.Parse(labelCpuPrice.Text)) * (int.Parse(labelQtyCpu.Text));

            // Display assigned calculated values to corresponding desk, chair, and computer subtotal labels.
            lblSubtDesk.Text = sub_desk.ToString("c");
            lblSubtChair.Text = sub_chair.ToString("c");
            lblSubtCPU.Text = sub_cpu.ToString("c");

            // subtotal equals added desk and chair and computer subtotals. Assign value to RoomSubtotal label.
            decimal subtotal = sub_desk + sub_chair + sub_cpu;
            labelRoomSubtotal.Text = subtotal.ToString("c");

            // total equals added subtotals and instructor station price . Assign value to RoomSubtotal label.
            decimal total = subtotal + decimal.Parse(labelInstStnPrice.Text);
            labelTotal.Text = total.ToString("c");
            return class_info;
        }
        private void buttonExit_Click(object sender, EventArgs e)
        {
            // The button is actually labeled "Main Menu".
            // Closes View Classroom and returns to Main Menu.
            this.Close();
        }
        // Load button color, display classroom information, calculate and display total number of pages.
        private void ViewClassroom_Load(object sender, EventArgs e)
        {
            buttonPrevious.BackColor = System.Drawing.Color.PapayaWhip; // Assign Previous button color.
            string[] class_info = DisplayClassroomInfo(); // Assign and display class_info from saved file.
            int page_total = class_info.Count()/14; // Calculate total number of pages.
            lblPageTotal.Text = page_total.ToString(); // Display total number of pages.
        }

        // Show the next page, if there is a next page. Highlight previous and next
        // buttons according to whether or not there is a previous or next page.
        private void buttonNext_Click(object sender, EventArgs e)
        {
            // Get current page number from corresponding label (set to 1 at load) and add one, 
            // get total pages from corresponding label and assign to page and page_total variables.
            int page = int.Parse(lblPage.Text)+1; int page_total = int.Parse(lblPageTotal.Text);

            // Page number cannot exceet total pages.
            // If it does, make page number equal to total pages.
            if (page > page_total)
            {
                page = page_total;
            }
            // If page number equals total pages, it can't increment, 
            // because it would exceed total pages.
            // So, un-highlight the next page button.
            if (page == page_total)
            {
                buttonNext.BackColor = System.Drawing.Color.PapayaWhip;
            }
            // Highlight previous page button, since it can't be on page one if the next
            // button was selected.
            buttonPrevious.BackColor = System.Drawing.Color.PaleGreen;

            // Display the new page number, display new page of classroom data.
            lblPage.Text = page.ToString();
            DisplayClassroomInfo();
        }
        // Show the previous page, if there is a previous page. Highlight previous and next
        // buttons according to whether or not there is a previous or next page.
        private void buttonPrevious_Click(object sender, EventArgs e)
        {
            // Get current page number from corresponding label (set to 1 at load) and subtract one, 
            int page = int.Parse(lblPage.Text)-1;

            // Page number cannot be less than one.
            // If it is, make page number equal to one.
            if (page < 1)
            {
                page = 1;
            }
            // If page number equals one, it can't decrement, 
            // because it would be page 0.
            // So, un-highlight the previous page button.
            if (page == 1)
            {
                buttonPrevious.BackColor = System.Drawing.Color.PapayaWhip;
            }
            // Highlight next page button, since it can't be on last page if the previous
            // button was selected.
            buttonNext.BackColor = System.Drawing.Color.PaleGreen;

            // Display the new page number, display new page of classroom data.
            lblPage.Text = page.ToString();
            DisplayClassroomInfo();
        }
    }
}
