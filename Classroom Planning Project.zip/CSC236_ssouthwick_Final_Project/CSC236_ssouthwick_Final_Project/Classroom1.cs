﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSC236_ssouthwick_Final_Project
//
//  Sheryl Southwick
//           Classroom Proposal
//                  Final Project   
{
    ///////////////////////////////////////////////////////////////////// 
    //The code below demonstrates declaring variables as Fields .      // 
    ///////////////////////////////////////////////////////////////////// 

    class Classroom1
    {
        // Fields.
        private string _name; // The class's name.
        private string _location; // The class's location.
        private int _room_number; // The class's room number.

        // Constructor.
        public void Classroom()
        {
            _name = "";
            _location = "";
            _room_number = 0000;
        }
        // Name property.
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        // Location property.
        public string Location
        {
            get { return _location; }
            set { _location = value; }
        }
        // Room Number property.
        public int RoomNumber
        {
            get { return _room_number; }
            set { _room_number = value; }
        }
    }
    ///////////////////////////////////////////////////////////////////// 
    //The code below demonstrates inheritance and polymorphism.        // 
    ///////////////////////////////////////////////////////////////////// 

    class Furnishings : Classroom1
    {
        // Fields.
        private int _qty; // The quantity of furniture.
        private string _style; // The style name.
        private decimal _price; // The price.

        // Constructor.
        public Furnishings()
        {
            _qty = 0;
            _style = "";
            _price = 0;
        }
        // Furniture quantity.
        public int Qty
        {
            get { return _qty; }
            set { _qty = value; }
        }
        // Style property.
        public string Style
        {
            get { return _style; }
            set { _style = value; }
        }
        // Price property.
        public decimal Price
        {
            get { return _price; }
            set { _price = value; }
        }
    }
    ///////////////////////////////////////////////////////////////////// 
    //The code below demonstrates inheritance and polymorphism.        // 
    ///////////////////////////////////////////////////////////////////// 
    class Desk : Furnishings
    {
        // Accept a string item integer, assign and return a corresponding desk price.
        public decimal DeskPrice(int item)
        {
            decimal price = 0;
            if (item == 0) price = 150;
            else if (item == 1) price = 95;
            else price = 65;
            return price;
        }
        // Accept a string item integer, assign and return a corresponding desk style.
        public string DeskStyle(int item)
        {
            string style = "";
            if (item == 0) style = "Evans Classic";
            else if (item == 1) style = "SturdyStudy";
            else style = "Basic";
            return style;
        }
    }
    class Chair : Furnishings
    {
        // Accept a string item integer, assign and return a corresponding chair price.
        public decimal ChairPrice(int item)
        {
            decimal price = 0;
            if (item == 0) price = 110;
            else if (item == 1) price = 95;
            else price = 75;
            return price;
        }
        // Accept a string item integer, assign and return a corresponding chair style.
        public string ChairStyle(int item)
        {
            string style = "";
            if (item == 0) style = "Evans Chair";
            else if (item == 1) style = "Good Chair";
            else style = "Basic Chair";
            return style;
        }
    }
    class CPU : Furnishings
    {
        // Accept a string item integer, assign and return a corresponding computer price.
        public decimal CPUPrice(int item)
        {
            decimal price = 0;
            if (item == 0) price = 1595;
            else if (item == 1) price = 1250;
            else price = 865;
            return price;
        }
        // Accept a string item integer, assign and return a corresponding computer style.
        public string CPUStyle(int item)
        {
            string style = "";
            if (item == 0) style = "ExpensiveFast";
            else if (item == 1) style = "Mediocre";
            else style = "LowEnd";
            return style;
        }
    }
    class InstStn : Furnishings
    {
        // Accept a string item integer, assign and return a corresponding instructor station price.
        public decimal InstStnPrice(int item)
        {
            decimal price = 0;
            if (item == 0) price = 2500;
            else if (item == 1) price = 1450;
            else price = 1250;

            ///////////////////////////////////////////////////////////////////// 
            //The code below demonstrates using the Math Class.                // 
            ///////////////////////////////////////////////////////////////////// 

            Math.Truncate(price);
            decimal sameprice = price;
            return sameprice;
        }
        // Accept a string item integer,assign and return a corresponding instructor station style.
        public string InstStnStyle(int item)
        {
            string style = "";
            if (item == 0) style = "Premium Station";
            else if (item == 1) style = "Standard Station";
            else style = "Basic Station";
            return style;
        }
    }
}
