﻿namespace CSC236_ssouthwick_Final_Project
{
    partial class AddClassroom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.buttonExit = new System.Windows.Forms.Button();
            this.labelRoomName = new System.Windows.Forms.Label();
            this.labelBuildingLocation = new System.Windows.Forms.Label();
            this.labelRoomNumber = new System.Windows.Forms.Label();
            this.labelDeskType = new System.Windows.Forms.Label();
            this.labelChairType = new System.Windows.Forms.Label();
            this.labelComputerType = new System.Windows.Forms.Label();
            this.labelInstStn = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblSubtDesk = new System.Windows.Forms.Label();
            this.lblSubtChair = new System.Windows.Forms.Label();
            this.lblSubtCPU = new System.Windows.Forms.Label();
            this.labelShoRmSubTtl = new System.Windows.Forms.Label();
            this.labelShowTotal = new System.Windows.Forms.Label();
            this.labelTotal = new System.Windows.Forms.Label();
            this.lblSubCost = new System.Windows.Forms.Label();
            this.buttonAddRoom = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxRoomName = new System.Windows.Forms.TextBox();
            this.textBoxBuildingLocation = new System.Windows.Forms.TextBox();
            this.textBoxRoomNumber = new System.Windows.Forms.TextBox();
            this.buttonSave = new System.Windows.Forms.Button();
            this.listBoxDesk = new System.Windows.Forms.ListBox();
            this.textBoxDesk = new System.Windows.Forms.TextBox();
            this.bxQtyDesk = new System.Windows.Forms.TextBox();
            this.listBoxChair = new System.Windows.Forms.ListBox();
            this.listBoxCPU = new System.Windows.Forms.ListBox();
            this.textBoxChair = new System.Windows.Forms.TextBox();
            this.textBoxCPU = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.bxQtyChair = new System.Windows.Forms.TextBox();
            this.bxQtyCPU = new System.Windows.Forms.TextBox();
            this.listBoxInst = new System.Windows.Forms.ListBox();
            this.textBoxInst = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.buttonStay = new System.Windows.Forms.Button();
            this.buttonLeave = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(501, 34);
            this.label1.TabIndex = 9;
            this.label1.Text = "Add Proposed Classroom Details";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonExit.Location = new System.Drawing.Point(700, 9);
            this.buttonExit.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(208, 41);
            this.buttonExit.TabIndex = 10;
            this.buttonExit.Text = "Main Menu";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // labelRoomName
            // 
            this.labelRoomName.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.labelRoomName.Location = new System.Drawing.Point(151, 70);
            this.labelRoomName.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelRoomName.Name = "labelRoomName";
            this.labelRoomName.Size = new System.Drawing.Size(185, 28);
            this.labelRoomName.TabIndex = 11;
            this.labelRoomName.Text = "Room Name";
            this.labelRoomName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelBuildingLocation
            // 
            this.labelBuildingLocation.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.labelBuildingLocation.Location = new System.Drawing.Point(67, 108);
            this.labelBuildingLocation.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelBuildingLocation.Name = "labelBuildingLocation";
            this.labelBuildingLocation.Size = new System.Drawing.Size(269, 28);
            this.labelBuildingLocation.TabIndex = 18;
            this.labelBuildingLocation.Text = "Building Location";
            this.labelBuildingLocation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelRoomNumber
            // 
            this.labelRoomNumber.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelRoomNumber.Location = new System.Drawing.Point(182, 146);
            this.labelRoomNumber.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelRoomNumber.Name = "labelRoomNumber";
            this.labelRoomNumber.Size = new System.Drawing.Size(154, 28);
            this.labelRoomNumber.TabIndex = 19;
            this.labelRoomNumber.Text = "Room Number";
            this.labelRoomNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelDeskType
            // 
            this.labelDeskType.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelDeskType.Location = new System.Drawing.Point(47, 195);
            this.labelDeskType.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelDeskType.Name = "labelDeskType";
            this.labelDeskType.Size = new System.Drawing.Size(212, 28);
            this.labelDeskType.TabIndex = 20;
            this.labelDeskType.Text = "Select Desk Style";
            this.labelDeskType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChairType
            // 
            this.labelChairType.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelChairType.Location = new System.Drawing.Point(294, 195);
            this.labelChairType.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelChairType.Name = "labelChairType";
            this.labelChairType.Size = new System.Drawing.Size(240, 28);
            this.labelChairType.TabIndex = 21;
            this.labelChairType.Text = "Select Chair Style";
            this.labelChairType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelComputerType
            // 
            this.labelComputerType.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelComputerType.Location = new System.Drawing.Point(657, 195);
            this.labelComputerType.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelComputerType.Name = "labelComputerType";
            this.labelComputerType.Size = new System.Drawing.Size(236, 28);
            this.labelComputerType.TabIndex = 22;
            this.labelComputerType.Text = "Select Computer Model";
            this.labelComputerType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelInstStn
            // 
            this.labelInstStn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelInstStn.Location = new System.Drawing.Point(34, 442);
            this.labelInstStn.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelInstStn.Name = "labelInstStn";
            this.labelInstStn.Size = new System.Drawing.Size(252, 28);
            this.labelInstStn.TabIndex = 42;
            this.labelInstStn.Text = "Select Instructor Station";
            this.labelInstStn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(14, 402);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 28);
            this.label7.TabIndex = 47;
            this.label7.Text = "Subtotals";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSubtDesk
            // 
            this.lblSubtDesk.Location = new System.Drawing.Point(182, 402);
            this.lblSubtDesk.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSubtDesk.Name = "lblSubtDesk";
            this.lblSubtDesk.Size = new System.Drawing.Size(154, 28);
            this.lblSubtDesk.TabIndex = 52;
            this.lblSubtDesk.Text = "0.00";
            this.lblSubtDesk.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSubtChair
            // 
            this.lblSubtChair.Location = new System.Drawing.Point(427, 402);
            this.lblSubtChair.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSubtChair.Name = "lblSubtChair";
            this.lblSubtChair.Size = new System.Drawing.Size(107, 28);
            this.lblSubtChair.TabIndex = 53;
            this.lblSubtChair.Text = "0.00";
            this.lblSubtChair.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSubtCPU
            // 
            this.lblSubtCPU.Location = new System.Drawing.Point(696, 402);
            this.lblSubtCPU.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSubtCPU.Name = "lblSubtCPU";
            this.lblSubtCPU.Size = new System.Drawing.Size(138, 28);
            this.lblSubtCPU.TabIndex = 54;
            this.lblSubtCPU.Text = "0.00";
            this.lblSubtCPU.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelShoRmSubTtl
            // 
            this.labelShoRmSubTtl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelShoRmSubTtl.Location = new System.Drawing.Point(493, 442);
            this.labelShoRmSubTtl.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelShoRmSubTtl.Name = "labelShoRmSubTtl";
            this.labelShoRmSubTtl.Size = new System.Drawing.Size(213, 80);
            this.labelShoRmSubTtl.TabIndex = 58;
            this.labelShoRmSubTtl.Text = "Room Cost before Instructor Station $";
            this.labelShoRmSubTtl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelShowTotal
            // 
            this.labelShowTotal.Location = new System.Drawing.Point(480, 533);
            this.labelShowTotal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelShowTotal.Name = "labelShowTotal";
            this.labelShowTotal.Size = new System.Drawing.Size(196, 28);
            this.labelShowTotal.TabIndex = 59;
            this.labelShowTotal.Text = "Total Room Cost  $";
            this.labelShowTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelTotal
            // 
            this.labelTotal.BackColor = System.Drawing.Color.PapayaWhip;
            this.labelTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelTotal.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotal.Location = new System.Drawing.Point(672, 522);
            this.labelTotal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(207, 49);
            this.labelTotal.TabIndex = 60;
            this.labelTotal.Text = "0";
            this.labelTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSubCost
            // 
            this.lblSubCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSubCost.Location = new System.Drawing.Point(716, 473);
            this.lblSubCost.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSubCost.Name = "lblSubCost";
            this.lblSubCost.Size = new System.Drawing.Size(163, 37);
            this.lblSubCost.TabIndex = 61;
            this.lblSubCost.Text = "0";
            this.lblSubCost.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // buttonAddRoom
            // 
            this.buttonAddRoom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonAddRoom.Location = new System.Drawing.Point(648, 677);
            this.buttonAddRoom.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.buttonAddRoom.Name = "buttonAddRoom";
            this.buttonAddRoom.Size = new System.Drawing.Size(245, 34);
            this.buttonAddRoom.TabIndex = 62;
            this.buttonAddRoom.Text = "Add New Classroom";
            this.buttonAddRoom.UseVisualStyleBackColor = false;
            this.buttonAddRoom.Click += new System.EventHandler(this.buttonAddRoom_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonClear.Location = new System.Drawing.Point(78, 677);
            this.buttonClear.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(181, 34);
            this.buttonClear.TabIndex = 63;
            this.buttonClear.Text = "Clear All Entries";
            this.buttonClear.UseVisualStyleBackColor = false;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // label4
            // 
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(24, 352);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 28);
            this.label4.TabIndex = 65;
            this.label4.Text = "Enter quantity:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tempus Sans ITC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label6.Location = new System.Drawing.Point(4, 726);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 19);
            this.label6.TabIndex = 66;
            this.label6.Text = "by Sheryl Southwick";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxRoomName
            // 
            this.textBoxRoomName.Location = new System.Drawing.Point(344, 68);
            this.textBoxRoomName.Name = "textBoxRoomName";
            this.textBoxRoomName.Size = new System.Drawing.Size(318, 30);
            this.textBoxRoomName.TabIndex = 67;
            // 
            // textBoxBuildingLocation
            // 
            this.textBoxBuildingLocation.Location = new System.Drawing.Point(344, 108);
            this.textBoxBuildingLocation.Name = "textBoxBuildingLocation";
            this.textBoxBuildingLocation.Size = new System.Drawing.Size(318, 30);
            this.textBoxBuildingLocation.TabIndex = 68;
            // 
            // textBoxRoomNumber
            // 
            this.textBoxRoomNumber.Location = new System.Drawing.Point(344, 144);
            this.textBoxRoomNumber.Name = "textBoxRoomNumber";
            this.textBoxRoomNumber.Size = new System.Drawing.Size(318, 30);
            this.textBoxRoomNumber.TabIndex = 69;
            // 
            // buttonSave
            // 
            this.buttonSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonSave.Location = new System.Drawing.Point(321, 677);
            this.buttonSave.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(245, 34);
            this.buttonSave.TabIndex = 70;
            this.buttonSave.Text = "Save Form";
            this.buttonSave.UseVisualStyleBackColor = false;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // listBoxDesk
            // 
            this.listBoxDesk.AllowDrop = true;
            this.listBoxDesk.FormattingEnabled = true;
            this.listBoxDesk.ItemHeight = 23;
            this.listBoxDesk.Items.AddRange(new object[] {
            "$150.00 Evans Classic",
            "$  95.00 SturdyStudy",
            "$  65.00 Basic"});
            this.listBoxDesk.Location = new System.Drawing.Point(38, 226);
            this.listBoxDesk.Name = "listBoxDesk";
            this.listBoxDesk.Size = new System.Drawing.Size(248, 73);
            this.listBoxDesk.TabIndex = 71;
            this.listBoxDesk.SelectedIndexChanged += new System.EventHandler(this.listBoxDesk_SelectedIndexChanged);
            // 
            // textBoxDesk
            // 
            this.textBoxDesk.Location = new System.Drawing.Point(38, 310);
            this.textBoxDesk.Name = "textBoxDesk";
            this.textBoxDesk.Size = new System.Drawing.Size(248, 30);
            this.textBoxDesk.TabIndex = 72;
            // 
            // bxQtyDesk
            // 
            this.bxQtyDesk.Location = new System.Drawing.Point(200, 352);
            this.bxQtyDesk.Name = "bxQtyDesk";
            this.bxQtyDesk.Size = new System.Drawing.Size(86, 30);
            this.bxQtyDesk.TabIndex = 73;
            this.bxQtyDesk.Text = "0";
            this.bxQtyDesk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.bxQtyDesk.TextChanged += new System.EventHandler(this.bxQtyDesk_TextChanged);
            // 
            // listBoxChair
            // 
            this.listBoxChair.AllowDrop = true;
            this.listBoxChair.FormattingEnabled = true;
            this.listBoxChair.ItemHeight = 23;
            this.listBoxChair.Items.AddRange(new object[] {
            "$110.00 Evans Chair",
            "$  95.00 Good Chair",
            "$  75.00 Basic Chair"});
            this.listBoxChair.Location = new System.Drawing.Point(321, 226);
            this.listBoxChair.Name = "listBoxChair";
            this.listBoxChair.Size = new System.Drawing.Size(257, 73);
            this.listBoxChair.TabIndex = 74;
            this.listBoxChair.SelectedIndexChanged += new System.EventHandler(this.listBoxChair_SelectedIndexChanged);
            // 
            // listBoxCPU
            // 
            this.listBoxCPU.AllowDrop = true;
            this.listBoxCPU.FormattingEnabled = true;
            this.listBoxCPU.ItemHeight = 23;
            this.listBoxCPU.Items.AddRange(new object[] {
            "$1,595.00 ExpensiveFast",
            "$1,250.00 Mediocre",
            "$   865.00 LowEnd"});
            this.listBoxCPU.Location = new System.Drawing.Point(612, 226);
            this.listBoxCPU.Name = "listBoxCPU";
            this.listBoxCPU.Size = new System.Drawing.Size(281, 73);
            this.listBoxCPU.TabIndex = 75;
            this.listBoxCPU.SelectedIndexChanged += new System.EventHandler(this.listBoxCPU_SelectedIndexChanged);
            // 
            // textBoxChair
            // 
            this.textBoxChair.Location = new System.Drawing.Point(321, 310);
            this.textBoxChair.Name = "textBoxChair";
            this.textBoxChair.Size = new System.Drawing.Size(257, 30);
            this.textBoxChair.TabIndex = 76;
            // 
            // textBoxCPU
            // 
            this.textBoxCPU.Location = new System.Drawing.Point(612, 305);
            this.textBoxCPU.Name = "textBoxCPU";
            this.textBoxCPU.Size = new System.Drawing.Size(281, 30);
            this.textBoxCPU.TabIndex = 77;
            // 
            // label3
            // 
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(317, 352);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 28);
            this.label3.TabIndex = 78;
            this.label3.Text = "Enter quantity:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(608, 352);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 28);
            this.label5.TabIndex = 79;
            this.label5.Text = "Enter quantity:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // bxQtyChair
            // 
            this.bxQtyChair.Location = new System.Drawing.Point(484, 352);
            this.bxQtyChair.Name = "bxQtyChair";
            this.bxQtyChair.Size = new System.Drawing.Size(94, 30);
            this.bxQtyChair.TabIndex = 80;
            this.bxQtyChair.Text = "0";
            this.bxQtyChair.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.bxQtyChair.TextChanged += new System.EventHandler(this.bxQtyChair_TextChanged);
            // 
            // bxQtyCPU
            // 
            this.bxQtyCPU.Location = new System.Drawing.Point(798, 350);
            this.bxQtyCPU.Name = "bxQtyCPU";
            this.bxQtyCPU.Size = new System.Drawing.Size(95, 30);
            this.bxQtyCPU.TabIndex = 81;
            this.bxQtyCPU.Text = "0";
            this.bxQtyCPU.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.bxQtyCPU.TextChanged += new System.EventHandler(this.bxQtyCPU_TextChanged);
            // 
            // listBoxInst
            // 
            this.listBoxInst.AllowDrop = true;
            this.listBoxInst.FormattingEnabled = true;
            this.listBoxInst.ItemHeight = 23;
            this.listBoxInst.Items.AddRange(new object[] {
            "$2,500.00 Premium Station",
            "$1,450.00 Standard Station",
            "$1,250.00 Basic Station"});
            this.listBoxInst.Location = new System.Drawing.Point(38, 473);
            this.listBoxInst.Name = "listBoxInst";
            this.listBoxInst.Size = new System.Drawing.Size(298, 73);
            this.listBoxInst.TabIndex = 82;
            this.listBoxInst.SelectedIndexChanged += new System.EventHandler(this.listBox3_SelectedIndexChanged);
            // 
            // textBoxInst
            // 
            this.textBoxInst.Location = new System.Drawing.Point(38, 552);
            this.textBoxInst.Name = "textBoxInst";
            this.textBoxInst.Size = new System.Drawing.Size(298, 30);
            this.textBoxInst.TabIndex = 83;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(143, 402);
            this.label9.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 28);
            this.label9.TabIndex = 84;
            this.label9.Text = " $";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(396, 402);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 28);
            this.label2.TabIndex = 85;
            this.label2.Text = " $";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(668, 402);
            this.label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 28);
            this.label8.TabIndex = 86;
            this.label8.Text = " $";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.DarkGreen;
            this.groupBox1.Controls.Add(this.buttonLeave);
            this.groupBox1.Controls.Add(this.buttonStay);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Location = new System.Drawing.Point(233, 226);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(578, 269);
            this.groupBox1.TabIndex = 87;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " ";
            this.groupBox1.Visible = false;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(111, 62);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(315, 84);
            this.label10.TabIndex = 0;
            this.label10.Text = "All data will be lost. Leave this Page?";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonStay
            // 
            this.buttonStay.BackColor = System.Drawing.Color.YellowGreen;
            this.buttonStay.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonStay.Location = new System.Drawing.Point(333, 176);
            this.buttonStay.Name = "buttonStay";
            this.buttonStay.Size = new System.Drawing.Size(193, 48);
            this.buttonStay.TabIndex = 1;
            this.buttonStay.Text = "No, Don\'t Leave";
            this.buttonStay.UseVisualStyleBackColor = false;
            this.buttonStay.Click += new System.EventHandler(this.buttonStay_Click);
            // 
            // buttonLeave
            // 
            this.buttonLeave.BackColor = System.Drawing.Color.YellowGreen;
            this.buttonLeave.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonLeave.Location = new System.Drawing.Point(88, 176);
            this.buttonLeave.Name = "buttonLeave";
            this.buttonLeave.Size = new System.Drawing.Size(193, 48);
            this.buttonLeave.TabIndex = 2;
            this.buttonLeave.Text = "Yes, Leave";
            this.buttonLeave.UseVisualStyleBackColor = false;
            this.buttonLeave.Click += new System.EventHandler(this.buttonLeave_Click);
            // 
            // AddClassroom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(963, 744);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBoxInst);
            this.Controls.Add(this.listBoxInst);
            this.Controls.Add(this.bxQtyCPU);
            this.Controls.Add(this.bxQtyChair);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxCPU);
            this.Controls.Add(this.textBoxChair);
            this.Controls.Add(this.listBoxCPU);
            this.Controls.Add(this.listBoxChair);
            this.Controls.Add(this.bxQtyDesk);
            this.Controls.Add(this.textBoxDesk);
            this.Controls.Add(this.listBoxDesk);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.textBoxRoomNumber);
            this.Controls.Add(this.textBoxBuildingLocation);
            this.Controls.Add(this.textBoxRoomName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonAddRoom);
            this.Controls.Add(this.lblSubCost);
            this.Controls.Add(this.labelTotal);
            this.Controls.Add(this.labelShowTotal);
            this.Controls.Add(this.labelShoRmSubTtl);
            this.Controls.Add(this.lblSubtCPU);
            this.Controls.Add(this.lblSubtChair);
            this.Controls.Add(this.lblSubtDesk);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labelInstStn);
            this.Controls.Add(this.labelComputerType);
            this.Controls.Add(this.labelChairType);
            this.Controls.Add(this.labelDeskType);
            this.Controls.Add(this.labelRoomNumber);
            this.Controls.Add(this.labelBuildingLocation);
            this.Controls.Add(this.labelRoomName);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "AddClassroom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddClassroom";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label labelRoomName;
        private System.Windows.Forms.Label labelBuildingLocation;
        private System.Windows.Forms.Label labelRoomNumber;
        private System.Windows.Forms.Label labelDeskType;
        private System.Windows.Forms.Label labelChairType;
        private System.Windows.Forms.Label labelComputerType;
        private System.Windows.Forms.Label labelInstStn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblSubtDesk;
        private System.Windows.Forms.Label lblSubtChair;
        private System.Windows.Forms.Label lblSubtCPU;
        private System.Windows.Forms.Label labelShoRmSubTtl;
        private System.Windows.Forms.Label labelShowTotal;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.Label lblSubCost;
        private System.Windows.Forms.Button buttonAddRoom;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxRoomName;
        private System.Windows.Forms.TextBox textBoxBuildingLocation;
        private System.Windows.Forms.TextBox textBoxRoomNumber;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.ListBox listBoxDesk;
        private System.Windows.Forms.TextBox textBoxDesk;
        private System.Windows.Forms.TextBox bxQtyDesk;
        private System.Windows.Forms.ListBox listBoxChair;
        private System.Windows.Forms.ListBox listBoxCPU;
        private System.Windows.Forms.TextBox textBoxChair;
        private System.Windows.Forms.TextBox textBoxCPU;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox bxQtyChair;
        private System.Windows.Forms.TextBox bxQtyCPU;
        private System.Windows.Forms.ListBox listBoxInst;
        private System.Windows.Forms.TextBox textBoxInst;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonLeave;
        private System.Windows.Forms.Button buttonStay;
        private System.Windows.Forms.Label label10;
    }
}