﻿namespace CSC236_ssouthwick_Final_Project
{
    partial class ViewClassroom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelRoomName = new System.Windows.Forms.Label();
            this.labelShowComputerType = new System.Windows.Forms.Label();
            this.labelChairPrice = new System.Windows.Forms.Label();
            this.labelCpuPrice = new System.Windows.Forms.Label();
            this.labeShowlChairType = new System.Windows.Forms.Label();
            this.labelDeskPrice = new System.Windows.Forms.Label();
            this.labelShowDeskType = new System.Windows.Forms.Label();
            this.labelShowRoomNumber = new System.Windows.Forms.Label();
            this.labelBuildingLocation = new System.Windows.Forms.Label();
            this.labelRoomNumber = new System.Windows.Forms.Label();
            this.labelA = new System.Windows.Forms.Label();
            this.lblWhichClass = new System.Windows.Forms.Label();
            this.buttonPrevious = new System.Windows.Forms.Button();
            this.buttonNext = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelDeskType = new System.Windows.Forms.Label();
            this.labelChairType = new System.Windows.Forms.Label();
            this.labelCPUType = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelQtyDesk = new System.Windows.Forms.Label();
            this.labelQtyChair = new System.Windows.Forms.Label();
            this.labelQtyCpu = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label1ShowInstStn = new System.Windows.Forms.Label();
            this.label1InstType = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.labelInstStnPrice = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblSubtDesk = new System.Windows.Forms.Label();
            this.lblSubtChair = new System.Windows.Forms.Label();
            this.lblSubtCPU = new System.Windows.Forms.Label();
            this.labelShoRmSubTtl = new System.Windows.Forms.Label();
            this.labelRoomSubtotal = new System.Windows.Forms.Label();
            this.labelShowTotal = new System.Windows.Forms.Label();
            this.labelTotal = new System.Windows.Forms.Label();
            this.lblPage = new System.Windows.Forms.Label();
            this.lblPageTotal = new System.Windows.Forms.Label();
            this.labelOf = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonExit.Location = new System.Drawing.Point(573, 637);
            this.buttonExit.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(188, 45);
            this.buttonExit.TabIndex = 7;
            this.buttonExit.Text = "Main Menu";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(84, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(449, 28);
            this.label1.TabIndex = 8;
            this.label1.Text = "Proposed Classroom Information";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelRoomName
            // 
            this.labelRoomName.Location = new System.Drawing.Point(22, 53);
            this.labelRoomName.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelRoomName.Name = "labelRoomName";
            this.labelRoomName.Size = new System.Drawing.Size(185, 28);
            this.labelRoomName.TabIndex = 9;
            this.labelRoomName.Text = "Room Name";
            this.labelRoomName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelShowComputerType
            // 
            this.labelShowComputerType.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelShowComputerType.Location = new System.Drawing.Point(13, 326);
            this.labelShowComputerType.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelShowComputerType.Name = "labelShowComputerType";
            this.labelShowComputerType.Size = new System.Drawing.Size(151, 28);
            this.labelShowComputerType.TabIndex = 10;
            this.labelShowComputerType.Text = "Computer Model";
            this.labelShowComputerType.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelChairPrice
            // 
            this.labelChairPrice.Location = new System.Drawing.Point(315, 250);
            this.labelChairPrice.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelChairPrice.Name = "labelChairPrice";
            this.labelChairPrice.Size = new System.Drawing.Size(98, 28);
            this.labelChairPrice.TabIndex = 11;
            this.labelChairPrice.Text = "$chair$";
            this.labelChairPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelCpuPrice
            // 
            this.labelCpuPrice.Location = new System.Drawing.Point(320, 326);
            this.labelCpuPrice.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelCpuPrice.Name = "labelCpuPrice";
            this.labelCpuPrice.Size = new System.Drawing.Size(93, 28);
            this.labelCpuPrice.TabIndex = 12;
            this.labelCpuPrice.Text = "$cpu$";
            this.labelCpuPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labeShowlChairType
            // 
            this.labeShowlChairType.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labeShowlChairType.Location = new System.Drawing.Point(54, 250);
            this.labeShowlChairType.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labeShowlChairType.Name = "labeShowlChairType";
            this.labeShowlChairType.Size = new System.Drawing.Size(110, 28);
            this.labeShowlChairType.TabIndex = 13;
            this.labeShowlChairType.Text = "Chair Style";
            this.labeShowlChairType.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelDeskPrice
            // 
            this.labelDeskPrice.Location = new System.Drawing.Point(324, 176);
            this.labelDeskPrice.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelDeskPrice.Name = "labelDeskPrice";
            this.labelDeskPrice.Size = new System.Drawing.Size(98, 28);
            this.labelDeskPrice.TabIndex = 14;
            this.labelDeskPrice.Text = "$desk$";
            this.labelDeskPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelShowDeskType
            // 
            this.labelShowDeskType.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelShowDeskType.Location = new System.Drawing.Point(57, 176);
            this.labelShowDeskType.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelShowDeskType.Name = "labelShowDeskType";
            this.labelShowDeskType.Size = new System.Drawing.Size(107, 28);
            this.labelShowDeskType.TabIndex = 15;
            this.labelShowDeskType.Text = "Desk Style";
            this.labelShowDeskType.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelShowRoomNumber
            // 
            this.labelShowRoomNumber.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelShowRoomNumber.Location = new System.Drawing.Point(53, 81);
            this.labelShowRoomNumber.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelShowRoomNumber.Name = "labelShowRoomNumber";
            this.labelShowRoomNumber.Size = new System.Drawing.Size(154, 28);
            this.labelShowRoomNumber.TabIndex = 16;
            this.labelShowRoomNumber.Text = "Room Number";
            this.labelShowRoomNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelBuildingLocation
            // 
            this.labelBuildingLocation.Location = new System.Drawing.Point(217, 53);
            this.labelBuildingLocation.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelBuildingLocation.Name = "labelBuildingLocation";
            this.labelBuildingLocation.Size = new System.Drawing.Size(238, 28);
            this.labelBuildingLocation.TabIndex = 17;
            this.labelBuildingLocation.Text = "Building Location";
            this.labelBuildingLocation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelRoomNumber
            // 
            this.labelRoomNumber.Location = new System.Drawing.Point(217, 81);
            this.labelRoomNumber.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelRoomNumber.Name = "labelRoomNumber";
            this.labelRoomNumber.Size = new System.Drawing.Size(238, 28);
            this.labelRoomNumber.TabIndex = 23;
            this.labelRoomNumber.Text = "room# here";
            this.labelRoomNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelA
            // 
            this.labelA.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelA.Location = new System.Drawing.Point(245, 176);
            this.labelA.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelA.Name = "labelA";
            this.labelA.Size = new System.Drawing.Size(74, 28);
            this.labelA.TabIndex = 25;
            this.labelA.Text = "cost $";
            this.labelA.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblWhichClass
            // 
            this.lblWhichClass.Location = new System.Drawing.Point(38, 616);
            this.lblWhichClass.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblWhichClass.Name = "lblWhichClass";
            this.lblWhichClass.Size = new System.Drawing.Size(264, 28);
            this.lblWhichClass.TabIndex = 26;
            this.lblWhichClass.Text = "details for classroom proposal ";
            this.lblWhichClass.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // buttonPrevious
            // 
            this.buttonPrevious.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonPrevious.Location = new System.Drawing.Point(57, 648);
            this.buttonPrevious.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.buttonPrevious.Name = "buttonPrevious";
            this.buttonPrevious.Size = new System.Drawing.Size(181, 34);
            this.buttonPrevious.TabIndex = 27;
            this.buttonPrevious.Text = "Previous Classroom";
            this.buttonPrevious.UseVisualStyleBackColor = false;
            this.buttonPrevious.Click += new System.EventHandler(this.buttonPrevious_Click);
            // 
            // buttonNext
            // 
            this.buttonNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonNext.Location = new System.Drawing.Point(280, 648);
            this.buttonNext.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.buttonNext.Name = "buttonNext";
            this.buttonNext.Size = new System.Drawing.Size(201, 34);
            this.buttonNext.TabIndex = 28;
            this.buttonNext.Text = "Next Classroom";
            this.buttonNext.UseVisualStyleBackColor = false;
            this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
            // 
            // label2
            // 
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(245, 250);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 28);
            this.label2.TabIndex = 29;
            this.label2.Text = "cost $";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(245, 326);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 28);
            this.label3.TabIndex = 30;
            this.label3.Text = "cost $";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelDeskType
            // 
            this.labelDeskType.Location = new System.Drawing.Point(129, 204);
            this.labelDeskType.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelDeskType.Name = "labelDeskType";
            this.labelDeskType.Size = new System.Drawing.Size(141, 28);
            this.labelDeskType.TabIndex = 31;
            this.labelDeskType.Text = "Desk Type";
            this.labelDeskType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelChairType
            // 
            this.labelChairType.Location = new System.Drawing.Point(129, 278);
            this.labelChairType.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelChairType.Name = "labelChairType";
            this.labelChairType.Size = new System.Drawing.Size(141, 28);
            this.labelChairType.TabIndex = 32;
            this.labelChairType.Text = "Chair Type";
            this.labelChairType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelCPUType
            // 
            this.labelCPUType.Location = new System.Drawing.Point(129, 354);
            this.labelCPUType.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelCPUType.Name = "labelCPUType";
            this.labelCPUType.Size = new System.Drawing.Size(141, 28);
            this.labelCPUType.TabIndex = 33;
            this.labelCPUType.Text = "cpu Type";
            this.labelCPUType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(256, 204);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 28);
            this.label5.TabIndex = 35;
            this.label5.Text = "quantity";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(256, 354);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 28);
            this.label6.TabIndex = 36;
            this.label6.Text = "quantity";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelQtyDesk
            // 
            this.labelQtyDesk.Location = new System.Drawing.Point(378, 204);
            this.labelQtyDesk.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelQtyDesk.Name = "labelQtyDesk";
            this.labelQtyDesk.Size = new System.Drawing.Size(59, 28);
            this.labelQtyDesk.TabIndex = 37;
            this.labelQtyDesk.Text = "#dsk";
            this.labelQtyDesk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelQtyChair
            // 
            this.labelQtyChair.Location = new System.Drawing.Point(378, 278);
            this.labelQtyChair.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelQtyChair.Name = "labelQtyChair";
            this.labelQtyChair.Size = new System.Drawing.Size(59, 28);
            this.labelQtyChair.TabIndex = 38;
            this.labelQtyChair.Text = "#chr";
            this.labelQtyChair.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelQtyCpu
            // 
            this.labelQtyCpu.Location = new System.Drawing.Point(378, 354);
            this.labelQtyCpu.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelQtyCpu.Name = "labelQtyCpu";
            this.labelQtyCpu.Size = new System.Drawing.Size(59, 28);
            this.labelQtyCpu.TabIndex = 39;
            this.labelQtyCpu.Text = "#cpu";
            this.labelQtyCpu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label10.Location = new System.Drawing.Point(256, 278);
            this.label10.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 28);
            this.label10.TabIndex = 40;
            this.label10.Text = "quantity";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1ShowInstStn
            // 
            this.label1ShowInstStn.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1ShowInstStn.Location = new System.Drawing.Point(-2, 402);
            this.label1ShowInstStn.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1ShowInstStn.Name = "label1ShowInstStn";
            this.label1ShowInstStn.Size = new System.Drawing.Size(166, 28);
            this.label1ShowInstStn.TabIndex = 41;
            this.label1ShowInstStn.Text = "Instructor Station";
            this.label1ShowInstStn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1InstType
            // 
            this.label1InstType.Location = new System.Drawing.Point(129, 430);
            this.label1InstType.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1InstType.Name = "label1InstType";
            this.label1InstType.Size = new System.Drawing.Size(121, 28);
            this.label1InstType.TabIndex = 42;
            this.label1InstType.Text = "standard";
            this.label1InstType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label12.Location = new System.Drawing.Point(245, 430);
            this.label12.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 28);
            this.label12.TabIndex = 43;
            this.label12.Text = "cost $";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelInstStnPrice
            // 
            this.labelInstStnPrice.Location = new System.Drawing.Point(319, 430);
            this.labelInstStnPrice.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelInstStnPrice.Name = "labelInstStnPrice";
            this.labelInstStnPrice.Size = new System.Drawing.Size(94, 28);
            this.labelInstStnPrice.TabIndex = 44;
            this.labelInstStnPrice.Text = "$inst$";
            this.labelInstStnPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(453, 153);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 28);
            this.label7.TabIndex = 46;
            this.label7.Text = "Subtotal";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(476, 204);
            this.label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 28);
            this.label8.TabIndex = 47;
            this.label8.Text = " $";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(476, 278);
            this.label9.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 28);
            this.label9.TabIndex = 48;
            this.label9.Text = " $";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(476, 354);
            this.label11.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 28);
            this.label11.TabIndex = 49;
            this.label11.Text = " $";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSubtDesk
            // 
            this.lblSubtDesk.Location = new System.Drawing.Point(499, 204);
            this.lblSubtDesk.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSubtDesk.Name = "lblSubtDesk";
            this.lblSubtDesk.Size = new System.Drawing.Size(104, 28);
            this.lblSubtDesk.TabIndex = 51;
            this.lblSubtDesk.Text = "$subDesk$";
            this.lblSubtDesk.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSubtChair
            // 
            this.lblSubtChair.Location = new System.Drawing.Point(499, 278);
            this.lblSubtChair.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSubtChair.Name = "lblSubtChair";
            this.lblSubtChair.Size = new System.Drawing.Size(104, 28);
            this.lblSubtChair.TabIndex = 52;
            this.lblSubtChair.Text = "$subChair$";
            this.lblSubtChair.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSubtCPU
            // 
            this.lblSubtCPU.Location = new System.Drawing.Point(499, 354);
            this.lblSubtCPU.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSubtCPU.Name = "lblSubtCPU";
            this.lblSubtCPU.Size = new System.Drawing.Size(104, 28);
            this.lblSubtCPU.TabIndex = 53;
            this.lblSubtCPU.Text = "$subCpu$";
            this.lblSubtCPU.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelShoRmSubTtl
            // 
            this.labelShoRmSubTtl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelShoRmSubTtl.Location = new System.Drawing.Point(22, 496);
            this.labelShoRmSubTtl.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelShoRmSubTtl.Name = "labelShoRmSubTtl";
            this.labelShoRmSubTtl.Size = new System.Drawing.Size(382, 28);
            this.labelShoRmSubTtl.TabIndex = 55;
            this.labelShoRmSubTtl.Text = "Room Cost before Instructor Station $";
            this.labelShoRmSubTtl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelRoomSubtotal
            // 
            this.labelRoomSubtotal.Location = new System.Drawing.Point(414, 496);
            this.labelRoomSubtotal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelRoomSubtotal.Name = "labelRoomSubtotal";
            this.labelRoomSubtotal.Size = new System.Drawing.Size(119, 28);
            this.labelRoomSubtotal.TabIndex = 56;
            this.labelRoomSubtotal.Text = "$subAll$";
            this.labelRoomSubtotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelShowTotal
            // 
            this.labelShowTotal.Location = new System.Drawing.Point(254, 540);
            this.labelShowTotal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelShowTotal.Name = "labelShowTotal";
            this.labelShowTotal.Size = new System.Drawing.Size(183, 28);
            this.labelShowTotal.TabIndex = 57;
            this.labelShowTotal.Text = "Total Room Cost  $";
            this.labelShowTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelTotal
            // 
            this.labelTotal.BackColor = System.Drawing.Color.PapayaWhip;
            this.labelTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelTotal.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotal.Location = new System.Drawing.Point(457, 540);
            this.labelTotal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(180, 28);
            this.labelTotal.TabIndex = 58;
            this.labelTotal.Text = "total";
            this.labelTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPage
            // 
            this.lblPage.Location = new System.Drawing.Point(295, 616);
            this.lblPage.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPage.Name = "lblPage";
            this.lblPage.Size = new System.Drawing.Size(24, 28);
            this.lblPage.TabIndex = 59;
            this.lblPage.Text = " 1";
            this.lblPage.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPageTotal
            // 
            this.lblPageTotal.Location = new System.Drawing.Point(357, 616);
            this.lblPageTotal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPageTotal.Name = "lblPageTotal";
            this.lblPageTotal.Size = new System.Drawing.Size(27, 28);
            this.lblPageTotal.TabIndex = 60;
            this.lblPageTotal.Text = "6";
            this.lblPageTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelOf
            // 
            this.labelOf.Location = new System.Drawing.Point(329, 616);
            this.labelOf.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelOf.Name = "labelOf";
            this.labelOf.Size = new System.Drawing.Size(27, 28);
            this.labelOf.TabIndex = 61;
            this.labelOf.Text = "of";
            this.labelOf.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Tempus Sans ITC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(11, 714);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 19);
            this.label4.TabIndex = 62;
            this.label4.Text = "by Sheryl Southwick";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ViewClassroom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(821, 728);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelOf);
            this.Controls.Add(this.lblPageTotal);
            this.Controls.Add(this.lblPage);
            this.Controls.Add(this.labelTotal);
            this.Controls.Add(this.labelShowTotal);
            this.Controls.Add(this.labelRoomSubtotal);
            this.Controls.Add(this.labelShoRmSubTtl);
            this.Controls.Add(this.lblSubtCPU);
            this.Controls.Add(this.lblSubtChair);
            this.Controls.Add(this.lblSubtDesk);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labelInstStnPrice);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label1InstType);
            this.Controls.Add(this.label1ShowInstStn);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.labelQtyCpu);
            this.Controls.Add(this.labelQtyChair);
            this.Controls.Add(this.labelQtyDesk);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelCPUType);
            this.Controls.Add(this.labelChairType);
            this.Controls.Add(this.labelDeskType);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonNext);
            this.Controls.Add(this.buttonPrevious);
            this.Controls.Add(this.lblWhichClass);
            this.Controls.Add(this.labelA);
            this.Controls.Add(this.labelRoomNumber);
            this.Controls.Add(this.labelBuildingLocation);
            this.Controls.Add(this.labelShowRoomNumber);
            this.Controls.Add(this.labelShowDeskType);
            this.Controls.Add(this.labelDeskPrice);
            this.Controls.Add(this.labeShowlChairType);
            this.Controls.Add(this.labelCpuPrice);
            this.Controls.Add(this.labelChairPrice);
            this.Controls.Add(this.labelShowComputerType);
            this.Controls.Add(this.labelRoomName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonExit);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "ViewClassroom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewClassroom";
            this.Load += new System.EventHandler(this.ViewClassroom_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelRoomName;
        private System.Windows.Forms.Label labelShowComputerType;
        private System.Windows.Forms.Label labelChairPrice;
        private System.Windows.Forms.Label labelCpuPrice;
        private System.Windows.Forms.Label labeShowlChairType;
        private System.Windows.Forms.Label labelDeskPrice;
        private System.Windows.Forms.Label labelShowDeskType;
        private System.Windows.Forms.Label labelShowRoomNumber;
        private System.Windows.Forms.Label labelBuildingLocation;
        private System.Windows.Forms.Label labelRoomNumber;
        private System.Windows.Forms.Label labelA;
        private System.Windows.Forms.Label lblWhichClass;
        private System.Windows.Forms.Button buttonPrevious;
        private System.Windows.Forms.Button buttonNext;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelDeskType;
        private System.Windows.Forms.Label labelChairType;
        private System.Windows.Forms.Label labelCPUType;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelQtyDesk;
        private System.Windows.Forms.Label labelQtyChair;
        private System.Windows.Forms.Label labelQtyCpu;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1ShowInstStn;
        private System.Windows.Forms.Label label1InstType;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label labelInstStnPrice;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblSubtDesk;
        private System.Windows.Forms.Label lblSubtChair;
        private System.Windows.Forms.Label lblSubtCPU;
        private System.Windows.Forms.Label labelShoRmSubTtl;
        private System.Windows.Forms.Label labelRoomSubtotal;
        private System.Windows.Forms.Label labelShowTotal;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.Label lblPage;
        private System.Windows.Forms.Label lblPageTotal;
        private System.Windows.Forms.Label labelOf;
        private System.Windows.Forms.Label label4;
    }
}